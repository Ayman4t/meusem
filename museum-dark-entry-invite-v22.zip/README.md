# Museum of Love

Open `museum.html` (it loads `index.html` inside a frame). Host the whole folder as-is.

## Folder map

```
index.html          page markup only (no inline css / js)
museum.html         wrapper that opens index.html
css/                styles, loaded in this order (later files override earlier ones)
  01-base-intro   02-hud-bubbles   03-letter-question   04-lightbox-guestbook
  05-editor-music 06-ux-love-theme 07-light-theme       08-dark-entry
  09-overrides    10-gift
js/                 scripts, loaded in this order (the order matters)
  00-sunset-photo     default garden photo (big base64 string, kept out of the code)
  01-config           texts (EN / AR), settings, standalone-export builder
  02-dom-storage      DOM handles, media store (IndexedDB), shared `state`
  03-audio            music engine + recorded sounds
  04-scene            Three.js scene, hall, TV, exit door
  05-rooms-frames     secret room, painting light, frames, end-wall screen
  06-avatars          avatars, name tags, speech bubbles
  07-controls-ui      lighting, input, lightbox, mini-map, customizer
  08-dark-entrance    dark entrance with the light cone
  09-story            state machine, letter, question, confetti, fireworks, guestbook
  10-main-loop        render loop, applying settings, loading screen
  11-customize-share  customize panel, share link, standalone file
  12-live             live mode (two people, one invitation)
  13-upgrades         warm hall, decor, garden, emotes, gallery extras
  14-music-picker     music picker, reactions
  15-avatar-faces     hand IK, faces
  16-observatory-plane observatory wing, the "I love you <name>" plane, garden
  17-rooms-extras     roof lights, photo booth, drawing studio, painter
  18-boot             start-up: runs last, after everything else is loaded
sounds/             sound effects (see sounds/CREDITS.txt)
```

## Where to change things

- Names, texts, captions: `js/01-config.js` (`from` / `to`).
- The plane banner: `js/16-observatory-plane.js` (`launchPlane`).
- Boy / girl speech bubbles: `css/02-hud-bubbles.css` + `css/06-ux-love-theme.css` (`.bubble`) and `say()` in `js/06-avatars.js`.
- The letter shown on the screen: `layoutLetter` / `drawLetterScreen` in `js/09-story.js`.

## Rules when editing

- All js files share one global scope, so a name is declared once. Keep the file order in `index.html`.
- Anything asynchronous that must wait for every file (loading bar, render loop) goes in `js/18-boot.js`.
